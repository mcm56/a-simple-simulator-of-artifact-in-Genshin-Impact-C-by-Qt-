/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 6.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *createb;
    QPushButton *cancelb;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QTextBrowser *mw;
    QTextBrowser *mn;
    QLabel *label;
    QLabel *label_2;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QTextBrowser *fw4;
    QTextBrowser *fw3;
    QTextBrowser *fw2;
    QTextBrowser *fw1;
    QTextBrowser *fn1;
    QTextBrowser *fn2;
    QTextBrowser *fn3;
    QTextBrowser *fn4;
    QLabel *label_3;
    QLabel *label_4;
    QTextBrowser *name;
    QLabel *label_5;
    QLabel *picture;
    QPushButton *up;
    QSpinBox *lv;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName("Widget");
        Widget->resize(800, 600);
        createb = new QPushButton(Widget);
        createb->setObjectName("createb");
        createb->setGeometry(QRect(190, 470, 80, 21));
        cancelb = new QPushButton(Widget);
        cancelb->setObjectName("cancelb");
        cancelb->setGeometry(QRect(450, 470, 80, 21));
        horizontalLayoutWidget = new QWidget(Widget);
        horizontalLayoutWidget->setObjectName("horizontalLayoutWidget");
        horizontalLayoutWidget->setGeometry(QRect(290, 50, 371, 62));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        mw = new QTextBrowser(horizontalLayoutWidget);
        mw->setObjectName("mw");

        horizontalLayout->addWidget(mw);

        mn = new QTextBrowser(horizontalLayoutWidget);
        mn->setObjectName("mn");

        horizontalLayout->addWidget(mn);

        label = new QLabel(Widget);
        label->setObjectName("label");
        label->setGeometry(QRect(360, 20, 49, 14));
        label_2 = new QLabel(Widget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(540, 20, 49, 14));
        formLayoutWidget = new QWidget(Widget);
        formLayoutWidget->setObjectName("formLayoutWidget");
        formLayoutWidget->setGeometry(QRect(350, 190, 351, 257));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName("formLayout");
        formLayout->setContentsMargins(0, 0, 0, 0);
        fw4 = new QTextBrowser(formLayoutWidget);
        fw4->setObjectName("fw4");

        formLayout->setWidget(3, QFormLayout::LabelRole, fw4);

        fw3 = new QTextBrowser(formLayoutWidget);
        fw3->setObjectName("fw3");

        formLayout->setWidget(2, QFormLayout::LabelRole, fw3);

        fw2 = new QTextBrowser(formLayoutWidget);
        fw2->setObjectName("fw2");

        formLayout->setWidget(1, QFormLayout::LabelRole, fw2);

        fw1 = new QTextBrowser(formLayoutWidget);
        fw1->setObjectName("fw1");

        formLayout->setWidget(0, QFormLayout::LabelRole, fw1);

        fn1 = new QTextBrowser(formLayoutWidget);
        fn1->setObjectName("fn1");

        formLayout->setWidget(0, QFormLayout::FieldRole, fn1);

        fn2 = new QTextBrowser(formLayoutWidget);
        fn2->setObjectName("fn2");

        formLayout->setWidget(1, QFormLayout::FieldRole, fn2);

        fn3 = new QTextBrowser(formLayoutWidget);
        fn3->setObjectName("fn3");

        formLayout->setWidget(2, QFormLayout::FieldRole, fn3);

        fn4 = new QTextBrowser(formLayoutWidget);
        fn4->setObjectName("fn4");

        formLayout->setWidget(3, QFormLayout::FieldRole, fn4);

        label_3 = new QLabel(Widget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(430, 160, 49, 14));
        label_4 = new QLabel(Widget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(640, 160, 49, 14));
        name = new QTextBrowser(Widget);
        name->setObjectName("name");
        name->setGeometry(QRect(10, 20, 256, 61));
        label_5 = new QLabel(Widget);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(350, 20, 49, 14));
        picture = new QLabel(Widget);
        picture->setObjectName("picture");
        picture->setGeometry(QRect(50, 100, 221, 191));
        up = new QPushButton(Widget);
        up->setObjectName("up");
        up->setGeometry(QRect(80, 420, 80, 21));
        lv = new QSpinBox(Widget);
        lv->setObjectName("lv");
        lv->setGeometry(QRect(100, 380, 42, 22));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        createb->setText(QCoreApplication::translate("Widget", "\347\224\237\346\210\220", nullptr));
        cancelb->setText(QCoreApplication::translate("Widget", "\345\217\226\346\266\210", nullptr));
        label->setText(QString());
        label_2->setText(QCoreApplication::translate("Widget", "\346\225\260\345\200\274", nullptr));
        label_3->setText(QCoreApplication::translate("Widget", "\345\261\236\346\200\247", nullptr));
        label_4->setText(QCoreApplication::translate("Widget", "\346\225\260\345\200\274", nullptr));
        label_5->setText(QCoreApplication::translate("Widget", "\345\261\236\346\200\247", nullptr));
        picture->setText(QCoreApplication::translate("Widget", "TextLabel", nullptr));
        up->setText(QCoreApplication::translate("Widget", "\345\274\272\345\214\226", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
